(()=>{
'use strict';
const D=window.TD_CASES||[];
const root=document.body.dataset.root||'';
const page=document.body.dataset.page||'home';
const $=(s,el=document)=>el.querySelector(s);
const $$=(s,el=document)=>Array.from(el.querySelectorAll(s));
const escapeHtml=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
const url=c=>root+'cities/'+c.slug+'/index.html';
const asset=a=>root+'assets/'+a;
const imageHtml=(c,cls='tileImage')=>`<img class="${cls}" src="${escapeHtml(c.photo.url)}" alt="${escapeHtml(c.photo.caption)}" loading="lazy" onerror="this.style.display='none';this.parentElement.classList.add('no-photo')">`;
const clock=()=>String(Math.floor(Date.now()/1000)%1000);
const safeLink=src=>/^https:\/\//i.test(src)?src:'#';
const fmtNum=(n)=>String(n).padStart(2,'0');
const menu=$('#menuToggle'); if(menu)menu.onclick=()=>{let x=$('#navlinks');let open=x.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));};
// The first screen cycles through every city. Starting away from Novorossiysk keeps every city equally prominent.
if(page==='home'){
 const slides=[3,1,14,4,22,13,2,0,20,15,5,25,11,39,6,16,8,10,7,27,30,32,...D.map(c=>c.id)].filter((id,i,a)=>a.indexOf(id)===i);
 let pos=0,elapsed=0,paused=false, pointerStart=null;
 const duration=6500;
 const hero=$('#hero'),photo=$('#heroPhoto'),title=$('#heroTitle'),subtitle=$('#heroSubtitle'),description=$('#heroDescription'),caseN=$('#heroCaseN'),heroLink=$('#heroCaseLink'),src=$('#heroPhotoCredit'),indexTxt=$('#heroIndex'),next=$('#upNext'),fill=$('#slideFill');
 function show(i){pos=(i+slides.length)%slides.length;elapsed=0; const c=D[slides[pos]];
  hero.classList.add('changing');caseN.textContent='ДЕЛО №'+c.number+' · '+c.district;title.textContent=c.city;subtitle.textContent=c.title;description.textContent=c.summary;heroLink.href=url(c);src.innerHTML=`Снимок: ${escapeHtml(c.photo.caption)} · <a href="${escapeHtml(safeLink(c.photo.source))}" target="_blank" rel="noopener">источник ↗</a>`;indexTxt.textContent=fmtNum(pos+1)+' / '+fmtNum(slides.length);fill.style.width='0%';
  const bg=$('#heroPhotoFallback'),featured=$('#featuredCityImg'),visualType=$('#featuredVisualType');
  bg.style.backgroundImage=`url("${asset('illustration-'+fmtNum(c.id)+'.webp')}")`;
  featured.src=asset('illustration-'+fmtNum(c.id)+'.webp');featured.style.opacity='1';visualType.textContent='ИГРОВАЯ ИЛЛЮСТРАЦИЯ · ФОТО ПО ССЫЛКЕ';
  photo.classList.add('loading');let nextImage=new Image();nextImage.onload=()=>{if(slides[pos]===c.id){photo.style.backgroundImage=`url("${c.photo.url.replace(/"/g,'%22')}")`;photo.classList.remove('loading');featured.src=c.photo.url;featured.style.opacity='1';visualType.textContent='ФОТО РЕАЛЬНОГО МЕСТА';}};
  nextImage.onerror=()=>{if(slides[pos]===c.id){photo.style.backgroundImage='none';photo.classList.remove('loading');featured.src=asset('illustration-'+fmtNum(c.id)+'.webp');featured.style.opacity='1';visualType.textContent='ИГРОВАЯ ИЛЛЮСТРАЦИЯ · ФОТО ПО ССЫЛКЕ';}};nextImage.src=c.photo.url;
  // Featured panel replaces old secondary-list layout; city changes automatically.

  setTimeout(()=>hero.classList.remove('changing'),350);
 }
 const nextSlide=()=>show(pos+1),prevSlide=()=>show(pos-1);
 $('#nextSlide').onclick=nextSlide;$('#prevSlide').onclick=prevSlide;
 hero.addEventListener('mouseenter',()=>paused=true);hero.addEventListener('mouseleave',()=>paused=false);
 hero.addEventListener('focusin',()=>paused=true);hero.addEventListener('focusout',()=>paused=false);
 hero.addEventListener('touchstart',e=>{pointerStart=e.touches[0].clientX},{passive:true});
 hero.addEventListener('touchend',e=>{if(pointerStart==null)return;const dx=e.changedTouches[0].clientX-pointerStart;if(Math.abs(dx)>65){dx<0?nextSlide():prevSlide();}pointerStart=null},{passive:true});
 let last=performance.now();setInterval(()=>{const now=performance.now(),delta=Math.min(150,now-last);last=now;if(!paused&&!document.hidden){elapsed+=delta; fill.style.width=(elapsed/duration*100)+'%';if(elapsed>=duration)nextSlide();}},100);
 show(0);
 const dialog=$('#storyDialog');const trigger=$('#showStoryForm');const close=$('#storyClose');
 if(trigger&&dialog){trigger.onclick=()=>dialog.showModal();close.onclick=()=>dialog.close();dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close()});
 $('#storyForm').addEventListener('submit',e=>{e.preventDefault();const f=e.currentTarget;const data=Object.fromEntries(new FormData(f).entries());if(!data.city.trim()||!data.title.trim()||!data.description.trim())return;try{localStorage.setItem('td-draft-story',JSON.stringify(data));$('#storyStatus').textContent='Черновик сохранён на этом устройстве. Отправка пока не подключена.';}catch{$('#storyStatus').textContent='Не удалось сохранить черновик. Скопируй текст вручную.';}});}
 // dynamically generated popular cases, representative spread of districts
 const featuredIds=[1,3,14,4,0,20,29,37];
 const popular=$('#popularTiles'); popular.innerHTML=featuredIds.map(id=>tile(D[id])).join('');
 const all=$('#allCases'); let search='',region='Все';
 const regions=['Все',...new Set(D.map(c=>c.district))];
 const regionEl=$('#regionChips');
 function filters(){regionEl.innerHTML=regions.map(r=>`<button type="button" class="chip ${r===region?'active':''}" data-region="${escapeHtml(r)}">${escapeHtml(r)}</button>`).join('');}
 function draw(){filters();let list=D.filter(c=>(region==='Все'||c.district===region)&&(!search||`${c.city} ${c.title} ${c.region} ${c.loc1} ${c.loc2}`.toLowerCase().includes(search))); all.innerHTML=list.length?list.map(tile).join(''):'<div class="fine">Ничего не найдено. Попробуй другой город.</div>';$('#caseCount').textContent='Найдено: '+list.length+' из '+D.length;}
 regionEl.onclick=e=>{const b=e.target.closest('[data-region]');if(!b)return;region=b.dataset.region;draw();};
 $('#search').oninput=e=>{search=e.target.value.trim().toLowerCase();draw();};
 $('.searchNav')?.addEventListener('click',()=>{$('#catalog').scrollIntoView({behavior:'smooth'});$('#search').focus();});
 draw();
 // Real geographic overview (illustrative background, actual city pin links)
 const map=$('#cityMap');const mapPts=window.TD_PINS||[];
 for(const m of mapPts){const c=D[m.id];if(!c)continue;const a=document.createElement('a');a.href=url(c);a.className='mapPin';a.style.left=m.x+'%';a.style.top=m.y+'%';a.title=c.city+' · '+c.title;a.setAttribute('aria-label','Открыть '+c.city);map.appendChild(a);}
}
function tile(c){return `<a class="caseTile" href="${url(c)}"><div class="photoFallback" style="background-image:url('${asset('illustration-'+fmtNum(c.id)+'.webp')}')"><span>Иллюстрация · фото из источника загружается</span></div>${imageHtml(c)}<div><div class="category">${escapeHtml(c.kind)} · ${escapeHtml(c.region)}</div><h3>${escapeHtml(c.city)}</h3><div class="sub">${escapeHtml(c.title)}</div><div class="tinymeta"><span>Дело №${escapeHtml(c.number)}</span><span>Открыть ↗</span></div></div></a>`;}
if(page==='case'){
 const c=D[+document.body.dataset.caseId];if(!c)return;
 const href=encodeURIComponent(c.city+', '+c.region);
 const photo=$('#casePhoto');photo.src=c.photo.url;photo.alt=c.photo.caption;photo.onerror=()=>{photo.style.display='none';const fb=$('#casePhotoFallback');fb.style.display='block';fb.style.background='linear-gradient(90deg,rgba(10,12,18,.45),rgba(10,12,18,.22)),url('+asset('illustration-'+fmtNum(c.id)+'.webp')+') center/cover';fb.innerHTML='<span style="position:absolute;right:22px;bottom:12px;color:#ffd095;font-size:11px">Иллюстрация · оригинал снимка по ссылке</span>';};
 $('#caseBreadcrumb').textContent=c.city+' · Дело №'+c.number;
 $('#caseKicker').textContent='ДЕЛО №'+c.number+' · '+c.district;
 $('#caseCity').textContent=c.city;$('#caseTitle').textContent=c.title;$('#caseIntro').textContent=c.intro;
 $('#caseSource').textContent=c.photo.caption;$('#caseSourceLink').href=safeLink(c.photo.source);
 $('#caseType').textContent=c.type;$('#caseEra').textContent=c.era;$('#caseRegion').textContent=c.region;
 $('#introText').textContent=c.summary;$('#caseFact').textContent=c.fact;$('#caseQuestion').textContent=c.question;
 $('#srcLink').href=safeLink(c.source);$('#srcLink').textContent='Открыть публикацию об истории ↗';
 $('#photoLink').href=safeLink(c.photo.source);$('#photoLink').textContent='Автор фотографии / публикация ↗';
 const places=[c.loc1,c.loc2,c.city+' · исторический центр'];
 $('#caseRoute').innerHTML=places.map((p,i)=>`<div class="routeStop"><span class="stopNum">0${i+1}</span><strong>${escapeHtml(p)}</strong><small>${i===0?'Главная географическая зацепка':i===1?'Вторая точка для сопоставления': 'Контекст города и история места'}</small><a style="font-size:12px;color:#ffa55e;text-decoration:underline" target="_blank" rel="noopener" href="https://www.openstreetmap.org/search?query=${encodeURIComponent(p+', '+c.city)}">Найти на карте ↗</a></div>`).join('');
 $('#caseMap').src=`https://www.openstreetmap.org/export/embed.html?bbox=${c.lon-.16}%2C${c.lat-.09}%2C${c.lon+.16}%2C${c.lat+.09}&layer=mapnik&marker=${c.lat}%2C${c.lon}`;
 $('#realMap').href=`https://www.openstreetmap.org/?mlat=${c.lat}&mlon=${c.lon}#map=11/${c.lat}/${c.lon}`;
 $('#nextCity').href=url(D[(c.id+1)%D.length]);$('#nextCity').textContent='Следующее дело: '+D[(c.id+1)%D.length].city+' ↗';
 createGame(c);
}
function createGame(c){
 const storage='temnoe-delo-adventure-v1-'+c.id;
 let state={step:0,finish:false};try{state={...state,...JSON.parse(localStorage.getItem(storage)||'null')};}catch{}
 const game=$('#questContent');
 function persist(){try{localStorage.setItem(storage,JSON.stringify(state));}catch{}}
 function sound(f=610){try{const A=window.AudioContext||window.webkitAudioContext;const ctx=window._ctx||new A();window._ctx=ctx;const o=ctx.createOscillator(),g=ctx.createGain();o.type='triangle';o.frequency.value=f;g.gain.value=.017;o.connect(g);g.connect(ctx.destination);o.start();g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.12);o.stop(ctx.currentTime+.12);}catch{}}
 const stageTitles=['Осмотр места','Восстанови снимок','Порядок проверки','Отдели факт от версии','Свяжи улики','Сформулируй вывод'];
 const cap=escapeHtml;
 let unlocked=false;
 function feedback(message,kind=''){const el=$('#qFeedback');if(el){el.textContent=message;el.className='feedback '+kind;}}
 function allow(message){unlocked=true;feedback(message,'good');$('#goNext').disabled=false;sound(820);}
 function nav(step){state.step=step;persist();draw();$('#quest').scrollIntoView({block:'start',behavior:'smooth'});}
 function draw(){unlocked=false;const s=state.step;
  $('#stageName').textContent=state.finish?'Дело завершено':(s+1)+'/6 · '+stageTitles[s];
  $('#questDots').innerHTML=stageTitles.map((t,i)=>`<span class="questDot ${i<s||state.finish?'done':i===s?'active':''}" title="${cap(t)}"></span>`).join('');
  if(state.finish){game.innerHTML=`<h3 class="questTitle">Дело №${cap(c.number)}. Предварительное заключение</h3><p class="questIntro">Ты восстановил изображение, разобрал источники, проверил связи между предметами и сформулировал версию. Теперь ты знаешь о городе больше — не благодаря выдуманным «секретным протоколам», а благодаря проверке известных мест и историй.</p><div class="factBreakdown"><div class="factBox"><b>Что известно</b><p>${cap(c.fact)}</p></div><div class="factBox"><b>Что ещё важно проверить</b><p>${cap(c.question)}</p></div></div><div class="taskActions"><a class="btn" href="${cap(safeLink(c.source))}" target="_blank" rel="noopener">Открыть настоящий источник ↗</a><button class="btn flat" id="restart">Начать заново</button></div>`;$('#restart').onclick=()=>{state={step:0,finish:false};persist();draw();};return;}
  const lead=`<div class="tagline" style="margin-bottom:9px">${cap(stageTitles[s])} · Игровая реконструкция</div>`;
  let body='';
  if(s===0)body=`${lead}<div class="artifactView"><div class="artifactPhoto" id="artifactPhoto"><div class="photoFallback" style="background:url('${asset('illustration-'+fmtNum(c.id)+'.webp')}') center/cover"><span>Игровая иллюстрация · оригинальное фото: ${cap(c.photo.caption)}</span></div><img src="${cap(c.photo.url)}" alt="${cap(c.photo.caption)}" onerror="this.style.display='none'"><button class="glintSpot" aria-label="Исследовать деталь" id="spot"></button></div><div class="artifactSide"><h3 class="questTitle">Посмотри внимательнее</h3><p>Перед тобой настоящее место, связанное с историей «${cap(c.title)}». Раз в несколько секунд на фото появляется лёгкий отблеск. Найди его, а затем изучи подсказку.</p><div class="feedback" id="qFeedback">Нажми на небольшую подсвеченную зону в фотографии. Камера плавно приблизится к находке.</div><div class="taskActions"><a href="${cap(safeLink(c.photo.source))}" target="_blank" rel="noopener" class="btn flat">Проверить фото ↗</a></div></div></div>`;
  if(s===1)body=`${lead}<h3 class="questTitle">Восстанови фотографию</h3><p class="questIntro">Кадр разделён на девять частей. Выдели две плитки подряд, чтобы поменять их местами. Это игровая фотографическая головоломка на основе снимка реальной точки.</p><div class="puzzleGrid" id="puzzleGrid"></div><div class="taskActions"><button class="btn flat" id="puzzleReset">Перемешать заново</button></div><div class="feedback" id="qFeedback">Собери изображение целиком. Номера помогают ориентироваться. Если фото недоступно, появится иллюстрация места.</div>`;
  if(s===2)body=`${lead}<h3 class="questTitle">Построй цепочку проверки</h3><p class="questIntro">Представь, что ты исследователь: в каком порядке разумнее изучать дело «${cap(c.title)}»? Расставь шаги не по красоте, а по логике расследования.</p><div class="routePuzzle" id="routePuzzle"></div><div class="feedback" id="qFeedback">Нажми на этапы по порядку. Ошибся — начни цепочку заново.</div>`;
  if(s===3)body=`${lead}<h3 class="questTitle">Документ, версия или вопрос?</h3><div class="artifactView"><div class="document"><div class="docHeadline">Архивная карточка · игровая копия</div><p>${cap(c.fact)}</p><div class="seal">ДЕЛО</div></div><div><p class="questIntro">Прочти три утверждения и классифицируй каждое. Здесь важна точность: не выдавай интригующее вступление за документ.</p><div class="classifyGrid" id="targetGrid"><button class="targetBox" data-class="fact">Подтверждаемое<br>сведение</button><button class="targetBox" data-class="story">Сюжетная<br>подводка</button><button class="targetBox" data-class="question">Открытый<br>вопрос</button></div></div></div><div class="feedback" id="qFeedback">Сначала нажми на фразу ниже, затем на её категорию.</div><div class="tilePuzzle" id="classifyItems"></div>`;
  if(s===4)body=`${lead}<h3 class="questTitle">Свяжи улики на доске</h3><p class="questIntro">У каждого дела есть место, исследуемый предмет и свидетельство. Найди пару, которая действительно задаёт направление проверки, а не подменяет информацию выдумкой.</p><div class="tilePuzzle" id="linkPuzzle"></div><div class="feedback" id="qFeedback">Выбери две карточки, образующие логическую связь. Они соединятся на доске.</div>`;
  if(s===5)body=`${lead}<h3 class="questTitle">Твоя версия событий</h3><p class="questIntro">${cap(c.question)}</p><div class="factBox"><b>Главный источник</b><p>${cap(c.fact)}</p><p><a style="color:#ffac75;text-decoration:underline" href="${cap(safeLink(c.source))}" target="_blank" rel="noopener">Открыть материал для сверки ↗</a></p></div><div class="taskActions" id="finalOptions"><button class="choice" data-final="0">Все подробности из рассказов точно доказаны</button><button class="choice" data-final="1">Отделяю известные факты от версий и отмечаю пробелы</button><button class="choice" data-final="2">Если документов мало, могу придумать их ради атмосферы</button></div><div class="feedback" id="qFeedback">Выбери самый обоснованный вывод.</div>`;
  game.innerHTML=body+`<div class="questFooter" style="margin:20px -25px -25px"><span class="progressMini">${s+1} / 6 · ${cap(c.city)}</span><div><button class="btn flat" id="goBack" ${s===0?'disabled':''}>← Назад</button> <button class="btn" id="goNext" disabled>${s===5?'Завершить дело ↗':'Продолжить →'}</button></div></div>`;
  $('#goBack').onclick=()=>{if(s>0)nav(s-1)};
  $('#goNext').onclick=()=>{if(!unlocked)return;if(s===5){state.finish=true;persist();draw();}else nav(s+1)};
  if(s===0){$('#spot').onclick=()=>{const im=$('#artifactPhoto img');im.style.transition='transform .7s';im.style.transformOrigin='55% 52%';im.style.transform='scale(1.18)';setTimeout(()=>im.style.transform='scale(1)',900);allow('Место осмотрено. Ты получил первую точку: '+c.loc1+'. Дальше понадобится восстановить снимок.');};}
  if(s===1)imagePuzzle(c);
  if(s===2)chainPuzzle(c);
  if(s===3)classPuzzle(c);
  if(s===4)linkPuzzle(c);
  if(s===5)$$('[data-final]',game).forEach(b=>b.onclick=()=>{let isCorrect=b.dataset.final==='1';$$('[data-final]',game).forEach(x=>x.classList.remove('correct','wrong'));b.classList.add(isCorrect?'correct':'wrong');if(isCorrect)allow('Точная формулировка. Версия не подменяет найденные факты.');else feedback('Слишком сильное утверждение. Вернись к фактам и границе доказательств.','bad');});
 }
 function imagePuzzle(c){const grid=$('#puzzleGrid');let original=[0,1,2,3,4,5,6,7,8], current=[];let selected=null;
  const imgSrc=c.photo.url;
  const initialize=()=>{current=[...original];for(let j=0;j<3;j++){let a=(c.id+j*3+2)%9,b=(c.id+j*5+5)%9;[current[a],current[b]]=[current[b],current[a]];}if(current.every((v,i)=>v===i)){[current[0],current[8]]=[current[8],current[0]];}selected=null;render();};
  const render=()=>{grid.innerHTML=current.map((id,pos)=>`<button class="puzzleTile ${selected===pos?'selected':''}" type="button" data-tile="${pos}" style="background-image:url('${imgSrc.replace(/'/g,'%27')}'),url('${asset('illustration-'+fmtNum(c.id)+'.webp')}');background-position:${(id%3)*50}% ${Math.floor(id/3)*50}%;"><span style="display:grid;place-items:center;color:#fff;background:#0c0f1488;width:24px;height:24px;margin:2px;border-radius:50%;font-size:11px;font-weight:800">${id+1}</span></button>`).join('');};
  grid.onclick=e=>{const tile=e.target.closest('[data-tile]');if(!tile)return;const i=+tile.dataset.tile;if(selected===null){selected=i;render();return;}[current[selected],current[i]]=[current[i],current[selected]];selected=null;render();sound(540);if(current.every((v,j)=>v===j)){allow('Фотография восстановлена. Теперь можно изучать последовательность проверки.');}};
  $('#puzzleReset').onclick=initialize;initialize();
 }
 function chainPuzzle(c){const tasks=[['Сначала',`Осмотреть место: ${c.loc1}`],['Затем',`Найти источник о ${c.title}`],['После',`Проверить противоречия и версии`]];let queue=[2,0,1],order=[];const rootEl=$('#routePuzzle');
  function show(){rootEl.innerHTML=queue.map(i=>`<button class="token" data-chain="${i}" ${order.includes(i)?'disabled style="opacity:.3"':''}>${escapeHtml(tasks[i][1])}</button>`).join('')+`<div style="flex-basis:100%;margin-top:10px;color:#ffb27a;font-size:13px">${order.map(i=>tasks[i][0]+' → ').join('')||'Начни с первого шага'}</div><button class="btn flat" id="resetChain" type="button">Сбросить порядок</button>`;$('#resetChain').onclick=()=>{order=[];show();};}
  rootEl.onclick=e=>{let b=e.target.closest('[data-chain]');if(!b)return;const chosen=+b.dataset.chain;if(chosen!==order.length){feedback('Такой порядок приведёт к поспешному выводу. Подумай, с чего начинается проверка.','bad');sound(260);order=[];show();return;}order.push(chosen);show();sound(510);if(order.length===3)allow('Верно: сначала место, затем источники и только после этого выводы.');};show();
 }
 function classPuzzle(c){const types=['fact','story','question'];const statements=[c.fact,c.intro,c.question];let current=null;const matched=new Set(),grid=$('#targetGrid'),items=$('#classifyItems');
  const drawItems=()=>{items.innerHTML=statements.map((s,i)=>`<button class="token ${current===i?'selected':''}" data-item="${i}" ${matched.has(i)?'disabled style="opacity:.4"':''}>${escapeHtml(s)}</button>`).join('');};
  items.onclick=e=>{const b=e.target.closest('[data-item]');if(!b)return;current=+b.dataset.item;drawItems();feedback('Теперь выбери подходящую категорию для фразы.');};
  grid.onclick=e=>{const b=e.target.closest('[data-class]');if(!b||current===null)return;const valid=b.dataset.class===types[current];if(valid){matched.add(current);b.classList.add('correct');current=null;drawItems();sound(710);feedback('Верно. Классифицировано: '+matched.size+'/3.','good');if(matched.size===3)allow('Ты отделил историческую справку, сюжетное вступление и вопрос расследования.');}else{feedback('Это другая категория. Сведения, вступление и вопрос играют разные роли.','bad');sound(210);}};drawItems();
 }
 function linkPuzzle(c){const cards=[{id:0,label:`Место: ${c.loc1}`},{id:1,label:`Предмет: ${c.artefact}`},{id:2,label:'Вымышленный протокол без источника'},{id:3,label:`Контекст: ${c.loc2}`}];let active=[];const el=$('#linkPuzzle');
  function draw(){el.innerHTML=cards.map(x=>`<button class="token ${active.includes(x.id)?'selected':''}" data-link="${x.id}">${escapeHtml(x.label)}</button>`).join('');}
  el.onclick=e=>{const b=e.target.closest('[data-link]');if(!b)return;const k=+b.dataset.link;if(active.includes(k)){active=active.filter(x=>x!==k);draw();return;}active.push(k);draw();sound(420);if(active.length===2){let good=active.includes(0)&&active.includes(1);if(good)allow('Связь найдена: место и предмет указывают, где искать и что проверять.');else{feedback('Здесь пока нет доказательной связи. Поддельные «архивные документы» не помогают.','bad');setTimeout(()=>{if(!unlocked){active=[];draw();}},750);}}};draw();
 }
 draw();
}
})();
