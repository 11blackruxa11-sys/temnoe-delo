"""ТЁМНОЕ ДЕЛО: backend for accounts, entitlements, creator submissions and YooKassa.
Run: uvicorn server:app --host 0.0.0.0 --port 8000
All real money functions are DISABLED unless merchant credentials are supplied.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
from urllib.parse import quote

import httpx
from fastapi import Body, Cookie, FastAPI, HTTPException, Request, Response
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from cryptography.fernet import Fernet, InvalidToken

BASE = Path(__file__).resolve().parent
DB_FILE = Path(os.getenv('TD_DB_PATH', str(BASE / 'data' / 'temnoe.sqlite3')))
DB_FILE.parent.mkdir(parents=True, exist_ok=True)
SHOP_ID = os.getenv('YOOKASSA_SHOP_ID', '')
SHOP_SECRET = os.getenv('YOOKASSA_SECRET_KEY', '')
PUBLIC_URL = os.getenv('PUBLIC_BASE_URL', 'http://127.0.0.1:8000').rstrip('/')
APP_ENV = os.getenv('APP_ENV', 'development')
IS_PRODUCTION = APP_ENV == 'production'
IS_PUBLIC_DEMO = APP_ENV == 'demo'
IS_PUBLIC = IS_PRODUCTION or IS_PUBLIC_DEMO
SAFE_DEAL_ENABLED = os.getenv('YOOKASSA_SAFE_DEAL', '0') == '1'
DEMO_PAYMENTS = not IS_PRODUCTION and os.getenv('TD_DEMO_PAYMENTS', '1') == '1' and not (SHOP_ID or SHOP_SECRET)
COOKIE_SECURE = IS_PUBLIC or PUBLIC_URL.startswith('https://')
ADMIN_EMAIL = os.getenv('ADMIN_EMAIL', '').strip().lower()
PAYOUT_ENCRYPTION_KEY = os.getenv('TD_PAYOUT_ENCRYPTION_KEY', '')
PAYOUT_CIPHER = Fernet(PAYOUT_ENCRYPTION_KEY.encode()) if PAYOUT_ENCRYPTION_KEY else None
OFFICIAL_PRICE_KOPEKS = 11000
COMMISSION_CREATION_KOPEKS = 100000
COMMISSION_PERCENT = 10
AUTH_COOKIE = 'td_session'

match = re.search(r'window\.TD_CASES\s*=\s*(\[.*?\]);', (BASE/'data.js').read_text('utf-8'), re.S)
if not match:
    raise RuntimeError('Не удалось загрузить каталог дел из data.js')
CASES = json.loads(match.group(1))
BY_SLUG = {c['slug']: c for c in CASES}

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
  username TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS entitlements (
  user_id INTEGER NOT NULL REFERENCES users(id), product TEXT NOT NULL, source TEXT NOT NULL,
  order_id TEXT, granted_at INTEGER NOT NULL, PRIMARY KEY(user_id, product)
);
CREATE TABLE IF NOT EXISTS proposals (
  id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id), city TEXT NOT NULL,
  title TEXT NOT NULL, synopsis TEXT NOT NULL, source_url TEXT NOT NULL DEFAULT '',
  price_kopeks INTEGER NOT NULL DEFAULT 11000, status TEXT NOT NULL DEFAULT 'proposed',
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, featured_image TEXT NOT NULL DEFAULT ''
);
CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT, proposal_id INTEGER NOT NULL REFERENCES proposals(id),
  sender_id INTEGER REFERENCES users(id), kind TEXT NOT NULL DEFAULT 'user', text TEXT NOT NULL, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
  id TEXT PRIMARY KEY, buyer_id INTEGER NOT NULL REFERENCES users(id), product TEXT NOT NULL,
  proposal_id INTEGER REFERENCES proposals(id), amount_kopeks INTEGER NOT NULL,
  seller_amount INTEGER NOT NULL DEFAULT 0, platform_amount INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'pending', payment_id TEXT UNIQUE, deal_id TEXT,
  created_at INTEGER NOT NULL, paid_at INTEGER
);
CREATE TABLE IF NOT EXISTS ledger (
  order_id TEXT PRIMARY KEY REFERENCES orders(id), seller_id INTEGER NOT NULL REFERENCES users(id),
  seller_amount INTEGER NOT NULL, platform_amount INTEGER NOT NULL,
  payout_status TEXT NOT NULL DEFAULT 'pending', payout_id TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS payout_methods (
  user_id INTEGER PRIMARY KEY REFERENCES users(id), provider TEXT NOT NULL,
  payout_token TEXT NOT NULL, updated_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders(buyer_id);
CREATE INDEX IF NOT EXISTS idx_messages_proposal ON messages(proposal_id);
CREATE INDEX IF NOT EXISTS idx_proposals_user ON proposals(user_id);
"""


def now():
    return int(time.time())


@contextmanager
def conn():
    db = sqlite3.connect(DB_FILE, timeout=20)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA foreign_keys=ON')
    db.execute('PRAGMA busy_timeout=10000')
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

with conn() as init_db:
    init_db.executescript(SCHEMA)


def row_dict(row):
    return dict(row) if row else None


def pass_hash(password: str) -> str:
    salt = secrets.token_bytes(16)
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 260_000)
    return salt.hex() + '$' + key.hex()


def check_pass(password: str, value: str) -> bool:
    try:
        salt_hex, hashed = value.split('$', 1)
        actual = hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt_hex), 260_000)
        return hmac.compare_digest(actual, bytes.fromhex(hashed))
    except Exception:
        return False


def get_user(request: Request, required=False):
    token = request.cookies.get(AUTH_COOKIE)
    if token:
        with conn() as db:
            user = db.execute('''SELECT u.id,u.email,u.username,u.role FROM sessions s
                 JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?''',
                (hashlib.sha256(token.encode()).hexdigest(), now())).fetchone()
        if user:
            return row_dict(user)
    if required:
        raise HTTPException(401, 'Нужно войти в аккаунт')
    return None


def check_origin(request: Request):
    # Cookies are SameSite=Lax; Origin verification adds protection against CSRF.
    origin = request.headers.get('origin')
    if origin:
        forwarded_proto = request.headers.get('x-forwarded-proto', request.url.scheme)
        request_origin = forwarded_proto + '://' + request.headers.get('host','')
        if origin.rstrip('/') not in (PUBLIC_URL, request_origin):
            raise HTTPException(403, 'Посторонний источник запроса')
    if IS_PUBLIC and not origin and request.method not in {'GET', 'HEAD'}:
        raise HTTPException(403, 'Отсутствует Origin')


def create_session(response: Response, user_id: int):
    token = secrets.token_urlsafe(32)
    with conn() as db:
        db.execute('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)',
                   (hashlib.sha256(token.encode()).hexdigest(), user_id, now()+30*86400))
    response.set_cookie(AUTH_COOKIE, token, httponly=True, secure=COOKIE_SECURE, samesite='lax', max_age=30*86400, path='/')


def require_admin(request: Request):
    user = get_user(request, True)
    if user['role'] != 'admin':
        raise HTTPException(403, 'Только для редактора')
    return user


def product_key(case_slug=None, proposal_id=None):
    return ('case:'+case_slug) if case_slug is not None else 'story:'+str(proposal_id)


def unlocked(user_id: int, product: str) -> bool:
    with conn() as db:
        return bool(db.execute('SELECT 1 FROM entitlements WHERE user_id=? AND product=?', (user_id, product)).fetchone())


def free_available(user_id: int) -> bool:
    with conn() as db:
        return not bool(db.execute("SELECT 1 FROM entitlements WHERE user_id=? AND source='first_free'", (user_id,)).fetchone())


def yoomoney(endpoint: str, payload: dict | None = None, idem: str | None = None) -> dict:
    if not SHOP_ID or not SHOP_SECRET:
        raise HTTPException(503, 'Платёжный провайдер ещё не подключён')
    method = 'POST' if payload is not None else 'GET'
    with httpx.Client(timeout=20.0, auth=(SHOP_ID, SHOP_SECRET)) as client:
        try:
            result = client.request(method, 'https://api.yookassa.ru/v3/'+endpoint.lstrip('/'), json=payload,
                                    headers={'Idempotence-Key': idem or str(uuid.uuid4())} if payload is not None else {})
            result.raise_for_status()
            return result.json()
        except (httpx.HTTPError, ValueError):
            raise HTTPException(502, 'Платёжный сервис не ответил. Попробуй позже')


def money(value):
    return f'{value / 100:.2f}'


app = FastAPI(title='ТЁМНОЕ ДЕЛО · Платформа', docs_url='/api/docs' if APP_ENV == 'development' else None, redoc_url=None)

@app.middleware('http')
async def response_safety_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    if IS_PUBLIC_DEMO:
        response.headers['X-Robots-Tag'] = 'noindex, nofollow'
    if request.url.path.startswith('/api/auth/'):
        response.headers['Cache-Control'] = 'no-store'
    return response

app.mount('/assets', StaticFiles(directory=BASE/'assets'), name='assets')


class Credentials(BaseModel):
    email: str = Field(min_length=5, max_length=200)
    password: str = Field(min_length=8, max_length=128)
    username: str = Field(default='', max_length=60)


@app.post('/api/auth/register')
def register(data: Credentials, request: Request, response: Response):
    check_origin(request)
    email = data.email.strip().lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', email):
        raise HTTPException(422, 'Некорректная почта')
    username = data.username.strip() or email.split('@')[0]
    if not 2 <= len(username) <= 60:
        raise HTTPException(422, 'Имя от 2 до 60 символов')
    with conn() as db:
        if db.execute('SELECT 1 FROM users WHERE email=?',(email,)).fetchone():
            raise HTTPException(409, 'Такая почта уже зарегистрирована')
        cur = db.execute('INSERT INTO users(email,password_hash,username,role,created_at) VALUES(?,?,?,?,?)',
                         (email, pass_hash(data.password), username, 'admin' if ADMIN_EMAIL and email==ADMIN_EMAIL else 'user', now()))
        user_id = cur.lastrowid
    create_session(response, user_id)
    return {'user': {'id': user_id,'email':email,'username':username}, 'first_free_available':True}


@app.post('/api/auth/login')
def login(data: Credentials, request: Request, response: Response):
    check_origin(request)
    # Same generic error to avoid account enumeration.
    with conn() as db:
        row = db.execute('SELECT * FROM users WHERE email=?',(data.email.strip().lower(),)).fetchone()
    if not row or not check_pass(data.password, row['password_hash']):
        raise HTTPException(401, 'Неверная почта или пароль')
    create_session(response, row['id'])
    return {'user':{'id':row['id'],'email':row['email'],'username':row['username']}}


@app.post('/api/auth/logout')
def logout(request: Request, response: Response):
    check_origin(request)
    token = request.cookies.get(AUTH_COOKIE)
    if token:
        with conn() as db:
            db.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
    response.delete_cookie(AUTH_COOKIE, path='/')
    return {'ok':True}


@app.get('/api/me')
def me(request: Request):
    user = get_user(request)
    if not user:
        return {'user':None,'first_free_available':False,'entitlements':[],'my_proposals':[],'earnings_kopeks':0,'orders':[]}
    with conn() as db:
        entitlements = [r['product'] for r in db.execute('SELECT product FROM entitlements WHERE user_id=?',(user['id'],)).fetchall()]
        proposals = [dict(r) for r in db.execute('SELECT id,city,title,status,price_kopeks,updated_at FROM proposals WHERE user_id=? ORDER BY id DESC',(user['id'],))]
        earnings = db.execute('SELECT COALESCE(SUM(seller_amount),0) AS total FROM ledger WHERE seller_id=?',(user['id'],)).fetchone()['total']
        orders = [dict(r) for r in db.execute('SELECT id,product,amount_kopeks,status,created_at FROM orders WHERE buyer_id=? ORDER BY created_at DESC LIMIT 15',(user['id'],))]
    return {'user':user,'first_free_available':free_available(user['id']),'entitlements':entitlements,'my_proposals':proposals,'earnings_kopeks':earnings,'orders':orders}


@app.get('/api/config')
def get_config():
    return {'official_city_price_kopeks':OFFICIAL_PRICE_KOPEKS,
            'creation_price_kopeks':COMMISSION_CREATION_KOPEKS,
            'platform_commission_percent':COMMISSION_PERCENT,
            'payment_mode':'demo' if DEMO_PAYMENTS else ('yookassa' if SHOP_ID and SHOP_SECRET else 'not_connected'),
            'marketplace_live':bool(SHOP_ID and SHOP_SECRET and SAFE_DEAL_ENABLED and PAYOUT_CIPHER)}


@app.get('/api/cases')
def catalog(request: Request):
    user = get_user(request)
    with conn() as db:
        stories = [dict(r) for r in db.execute('SELECT p.id,p.city,p.title,p.synopsis,p.price_kopeks,p.source_url,p.user_id,u.username AS author FROM proposals p JOIN users u ON u.id=p.user_id WHERE status=? ORDER BY p.id DESC',('published',))]
    if user:
        with conn() as db:
            keys = {r['product'] for r in db.execute('SELECT product FROM entitlements WHERE user_id=?',(user['id'],))}
    else:
        keys = set()
    return {'official':[{'id':c['id'],'slug':c['slug'],'city':c['city'],'title':c['title'],'price_kopeks':OFFICIAL_PRICE_KOPEKS, 'unlocked':product_key(case_slug=c['slug']) in keys} for c in CASES],
            'community':[{'id':s['id'],'city':s['city'],'title':s['title'],'author':s['author'],'price_kopeks':s['price_kopeks'],'unlocked':product_key(proposal_id=s['id']) in keys or (user and user['id']==s['user_id'])} for s in stories]}


class Claim(BaseModel):
    slug: str


@app.post('/api/claim-free')
def claim_free(data: Claim, request: Request):
    check_origin(request)
    user = get_user(request,True)
    if data.slug not in BY_SLUG:
        raise HTTPException(404,'Такого города нет')
    product = product_key(case_slug=data.slug)
    with conn() as db:
        db.execute('BEGIN IMMEDIATE')
        if db.execute('SELECT 1 FROM entitlements WHERE user_id=? AND product=?',(user['id'],product)).fetchone():
            return {'ok':True,'url':'/cities/'+data.slug+'/index.html','already_owned':True}
        if db.execute("SELECT 1 FROM entitlements WHERE user_id=? AND source='first_free'",(user['id'],)).fetchone():
            raise HTTPException(409, 'Бесплатное дело уже выбрано. Другие города стоят 110 ₽')
        db.execute('INSERT INTO entitlements(user_id,product,source,granted_at) VALUES(?,?,?,?)',
                   (user['id'],product,'first_free',now()))
    return {'ok':True,'url':'/cities/'+data.slug+'/index.html','already_owned':False}


class ProposalIn(BaseModel):
    city: str = Field(min_length=2,max_length=80)
    title: str = Field(min_length=5,max_length=160)
    synopsis: str = Field(min_length=30,max_length=6000)
    source_url: str = Field(default='',max_length=1000)
    price_rub: int = Field(default=110, ge=50, le=10000)


@app.post('/api/proposals')
def new_proposal(data: ProposalIn, request: Request):
    check_origin(request)
    user=get_user(request,True)
    source=data.source_url.strip()
    if source and not re.match(r'^https://[^\s]+$',source):
        raise HTTPException(422,'Укажи https-ссылку на источник')
    with conn() as db:
        cur=db.execute('INSERT INTO proposals(user_id,city,title,synopsis,source_url,price_kopeks,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?)',
                       (user['id'],data.city.strip(),data.title.strip(),data.synopsis.strip(),source,data.price_rub*100,now(),now()))
        pid=cur.lastrowid
        db.execute('INSERT INTO messages(proposal_id,sender_id,kind,text,created_at) VALUES(?,?,?,?,?)',
                   (pid,user['id'],'user',data.synopsis.strip(),now()))
        db.execute('INSERT INTO messages(proposal_id,kind,text,created_at) VALUES(?,?,?,?)',
                   (pid,'system','Заявка поступила в редакцию. Здесь можно общаться и присылать источники. Разработка интерактивного дела стоит 1 000 ₽ только после согласования.',now()))
    return {'id':pid,'status':'proposed','message':'История отправлена на рассмотрение бесплатно'}


@app.get('/api/proposals/{pid}')
def read_proposal(pid: int,request:Request):
    user=get_user(request,True)
    with conn() as db:
        prop=db.execute('SELECT * FROM proposals WHERE id=?',(pid,)).fetchone()
        if not prop:
            raise HTTPException(404,'Заявка не найдена')
        if prop['user_id']!=user['id'] and user['role']!='admin':
            raise HTTPException(403,'Это чужая переписка')
        messages=[dict(r) for r in db.execute('SELECT m.id,m.kind,m.text,m.created_at,u.username FROM messages m LEFT JOIN users u ON u.id=m.sender_id WHERE proposal_id=? ORDER BY m.id',(pid,))]
    p=dict(prop)
    p.pop('user_id',None)
    return {'proposal':p,'messages':messages}


class MessageIn(BaseModel):
    text:str=Field(min_length=1,max_length=4000)


@app.post('/api/proposals/{pid}/messages')
def post_message(pid:int,data:MessageIn,request:Request):
    check_origin(request)
    user=get_user(request,True)
    with conn() as db:
        p=db.execute('SELECT user_id FROM proposals WHERE id=?',(pid,)).fetchone()
        if not p:
            raise HTTPException(404,'Заявка не найдена')
        if p['user_id']!=user['id'] and user['role']!='admin':
            raise HTTPException(403,'Это чужая переписка')
        db.execute('INSERT INTO messages(proposal_id,sender_id,kind,text,created_at) VALUES(?,?,?,?,?)',
                   (pid,user['id'],'editor' if user['role']=='admin' else 'user',data.text.strip(),now()))
        db.execute('UPDATE proposals SET updated_at=? WHERE id=?',(now(),pid))
    return {'ok':True}


class PriceIn(BaseModel):
    price_rub:int=Field(ge=50,le=10000)


@app.post('/api/proposals/{pid}/price')
def change_price(pid:int,data:PriceIn,request:Request):
    check_origin(request)
    user=get_user(request,True)
    with conn() as db:
        p=db.execute('SELECT user_id FROM proposals WHERE id=?',(pid,)).fetchone()
        if not p:
            raise HTTPException(404,'Заявка не найдена')
        if p['user_id']!=user['id']:
            raise HTTPException(403,'Это не твоя история')
        db.execute('UPDATE proposals SET price_kopeks=?, updated_at=? WHERE id=?',(data.price_rub*100, now(),pid))
    return {'price_kopeks':data.price_rub*100,'author_share_kopeks':data.price_rub*90,'platform_share_kopeks':data.price_rub*10}


class CheckoutIn(BaseModel):
    kind: Literal['city','story','creation']
    slug: str|None=None
    proposal_id:int|None=None


@app.post('/api/checkout')
def checkout(data:CheckoutIn,request:Request):
    check_origin(request)
    user=get_user(request,True)
    buyer_id=user['id']
    proposal_id=None
    if data.kind=='city':
        if not data.slug or data.slug not in BY_SLUG:
            raise HTTPException(404,'Город не найден')
        product=product_key(case_slug=data.slug)
        amount=OFFICIAL_PRICE_KOPEKS
        seller_amount=0
    else:
        if not data.proposal_id:
            raise HTTPException(422,'Укажи историю')
        with conn() as db:
            p=db.execute('SELECT * FROM proposals WHERE id=?',(data.proposal_id,)).fetchone()
        if not p:
            raise HTTPException(404,'История не найдена')
        proposal_id=p['id']
        if data.kind=='creation':
            if p['user_id']!=buyer_id:
                raise HTTPException(403,'Разработку истории может заказать её автор')
            if p['status'] not in ('proposed','reviewed'):
                raise HTTPException(409,'Сейчас нельзя оплатить разработку этой истории')
            product='creation:'+str(proposal_id)
            amount=COMMISSION_CREATION_KOPEKS
            seller_amount=0
        else:
            if p['status']!='published':
                raise HTTPException(409,'История ещё не опубликована')
            if p['user_id']==buyer_id:
                raise HTTPException(409,'Собственная история доступна автору бесплатно')
            product=product_key(proposal_id=proposal_id)
            amount=p['price_kopeks']
            seller_amount=(amount*90+50)//100
    if data.kind!='creation' and unlocked(buyer_id,product):
        return {'already_owned':True,'product':product}
    # For a safely monetized creator story, SAFE DEAL must be enabled and signed.
    if data.kind=='story' and not (DEMO_PAYMENTS or (SAFE_DEAL_ENABLED and SHOP_ID and SHOP_SECRET and PAYOUT_CIPHER)):
        raise HTTPException(503,'Автоматические выплаты авторам ещё не подключены. Продажи временно отключены.')
    if not DEMO_PAYMENTS and not (SHOP_ID and SHOP_SECRET):
        raise HTTPException(503,'Оплата ещё не подключена. Никакие деньги не списаны.')
    order_id=str(uuid.uuid4())
    platform_amount=amount-seller_amount
    with conn() as db:
        db.execute('INSERT INTO orders(id,buyer_id,product,proposal_id,amount_kopeks,seller_amount,platform_amount,created_at) VALUES(?,?,?,?,?,?,?,?)',
                   (order_id,buyer_id,product,proposal_id,amount,seller_amount,platform_amount,now()))
    if DEMO_PAYMENTS:
        return {'order_id':order_id,'amount_kopeks':amount,'mode':'demo','demo':True,
                'message':'Тестовая оплата. Реальные деньги не списываются.'}
    try:
        deal_id=None
        if data.kind=='story':
            deal=yoomoney('deals',{'type':'safe_deal','fee_moment':'deal_closed','description':'Тёмное дело · история '+str(proposal_id), 'metadata':{'order_id':order_id}},'deal-'+order_id)
            deal_id=deal['id']
        payload={'amount':{'value':money(amount),'currency':'RUB'},'capture':True,
                 'confirmation':{'type':'redirect','return_url':PUBLIC_URL+'/profile.html?payment='+order_id},
                 'description':'ТЁМНОЕ ДЕЛО: '+product[:60],
                 'metadata':{'order_id':order_id,'product':product}}
        if deal_id:
            payload['deal']={'id':deal_id,'settlements':[{'type':'payout','amount':{'value':money(seller_amount),'currency':'RUB'}}]}
        payment=yoomoney('payments',payload,'pay-'+order_id)
        payment_id=payment['id']
        confirmation=payment.get('confirmation',{}).get('confirmation_url')
        with conn() as db:
            db.execute('UPDATE orders SET payment_id=?,deal_id=? WHERE id=?',(payment_id,deal_id,order_id))
        if not confirmation:
            raise HTTPException(502,'Платёж создан, но ссылка подтверждения отсутствует')
        return {'order_id':order_id,'amount_kopeks':amount,'mode':'yookassa','confirmation_url':confirmation}
    except Exception:
        with conn() as db:
            db.execute("UPDATE orders SET status='error' WHERE id=? AND status='pending'",(order_id,))
        raise


def settle_order(order_id:str,payment_id:str|None=None):
    # Call only after trusted YooKassa GET verification, or explicitly in LOCAL DEMO mode.
    with conn() as db:
        db.execute('BEGIN IMMEDIATE')
        o=db.execute('SELECT * FROM orders WHERE id=?',(order_id,)).fetchone()
        if not o:
            raise HTTPException(404,'Заказ не найден')
        if payment_id is not None and o['payment_id'] != payment_id:
            raise HTTPException(409,'Платёж не соответствует заказу')
        if o['status']=='paid':
            return {'ok':True,'already_processed':True}
        if o['status'] not in ('pending','error'):
            raise HTTPException(409,'Неверный статус заказа')
        db.execute("UPDATE orders SET status='paid',paid_at=? WHERE id=?",(now(),order_id))
        if o['product'].startswith('creation:'):
            db.execute("UPDATE proposals SET status='paid_development',updated_at=? WHERE id=?",(now(),o['proposal_id']))
            db.execute('INSERT INTO messages(proposal_id,kind,text,created_at) VALUES(?,?,?,?)',
                       (o['proposal_id'],'system','Разработка оплачена. Редактор должен подготовить и проверить историю перед публикацией.',now()))
        else:
            db.execute('INSERT OR IGNORE INTO entitlements(user_id,product,source,order_id,granted_at) VALUES(?,?,?,?,?)',
                       (o['buyer_id'],o['product'],'purchase',o['id'],now()))
        if o['seller_amount']:
            p=db.execute('SELECT user_id FROM proposals WHERE id=?',(o['proposal_id'],)).fetchone()
            if not p:
                raise HTTPException(409,'Автор не найден')
            db.execute('INSERT OR IGNORE INTO ledger(order_id,seller_id,seller_amount,platform_amount,created_at) VALUES(?,?,?,?,?)',
                       (order_id,p['user_id'],o['seller_amount'],o['platform_amount'],now()))
    return {'ok':True,'already_processed':False}


@app.post('/api/dev/complete/{order_id}')
def demo_complete(order_id:str,request:Request):
    check_origin(request)
    if not DEMO_PAYMENTS:
        raise HTTPException(404,'Тестовый режим отключён')
    user=get_user(request,True)
    with conn() as db:
        order=db.execute('SELECT buyer_id FROM orders WHERE id=?',(order_id,)).fetchone()
    if not order or order['buyer_id']!=user['id']:
        raise HTTPException(404,'Заказ не найден')
    result=settle_order(order_id)
    result['demo']=True
    return result


@app.post('/api/webhooks/yookassa')
async def yookassa_webhook(request:Request):
    # Never trust webhook body without fetching payment from YooKassa over authenticated API.
    if not SHOP_ID or not SHOP_SECRET:
        raise HTTPException(503,'Платёжный провайдер не настроен')
    body=await request.json()
    if body.get('event') not in ('payment.succeeded','payment.canceled'):
        return {'ok':True}
    obj=body.get('object') or {}
    payment_id=obj.get('id')
    if not payment_id or not re.fullmatch('[a-zA-Z0-9-]{8,100}',payment_id):
        raise HTTPException(422,'Неверный идентификатор платежа')
    verified=yoomoney('payments/'+payment_id)
    if verified.get('id')!=payment_id:
        raise HTTPException(409,'Не найден платёж')
    order_id=verified.get('metadata',{}).get('order_id')
    with conn() as db:
        order=db.execute('SELECT * FROM orders WHERE id=? AND payment_id=?',(order_id,payment_id)).fetchone()
    if not order:
        raise HTTPException(404,'Связанный заказ не найден')
    if verified.get('amount',{}).get('currency')!='RUB' or verified.get('amount',{}).get('value')!=money(order['amount_kopeks']):
        raise HTTPException(409,'Сумма платежа не совпадает')
    if verified.get('status')=='succeeded' and verified.get('paid') is True:
        settle_order(order_id,payment_id)
    elif verified.get('status')=='canceled':
        with conn() as db:
            db.execute("UPDATE orders SET status='canceled' WHERE id=? AND status='pending'",(order_id,))
    return {'ok':True}


@app.post('/api/orders/{order_id}/verify')
def verify_order(order_id:str,request:Request):
    check_origin(request)
    user=get_user(request,True)
    with conn() as db:
        o=db.execute('SELECT * FROM orders WHERE id=? AND buyer_id=?',(order_id,user['id'])).fetchone()
    if not o:
        raise HTTPException(404,'Заказ не найден')
    if o['status']=='paid':
        return {'status':'paid'}
    if DEMO_PAYMENTS:
        return {'status':o['status'],'demo':True}
    if not o['payment_id']:
        return {'status':o['status']}
    payment=yoomoney('payments/'+o['payment_id'])
    if payment.get('status')=='succeeded' and payment.get('paid') is True and payment.get('amount',{}).get('value')==money(o['amount_kopeks']):
        settle_order(order_id,o['payment_id'])
        return {'status':'paid'}
    return {'status':payment.get('status','pending')}


@app.get('/api/author/earnings')
def author_earnings(request:Request):
    user=get_user(request,True)
    with conn() as db:
        rows=[dict(r) for r in db.execute('SELECT l.order_id,l.seller_amount,l.platform_amount,l.payout_status,l.created_at,p.title FROM ledger l JOIN orders o ON o.id=l.order_id JOIN proposals p ON p.id=o.proposal_id WHERE l.seller_id=? ORDER BY l.created_at DESC',(user['id'],))]
    return {'gross_kopeks':sum(r['seller_amount'] for r in rows),'transactions':rows,'commission_percent':10}


@app.get('/api/admin/proposals')
def admin_proposals(request:Request):
    require_admin(request)
    with conn() as db:
        return {'proposals':[dict(r) for r in db.execute('SELECT p.*,u.email,u.username FROM proposals p JOIN users u ON u.id=p.user_id ORDER BY p.updated_at DESC LIMIT 100')]}


class ModerateIn(BaseModel):
    status:Literal['reviewed','rejected','published']
    note:str=Field(default='',max_length=1000)


@app.post('/api/admin/proposals/{pid}/moderate')
def moderate(pid:int,data:ModerateIn,request:Request):
    check_origin(request)
    editor=require_admin(request)
    with conn() as db:
        p=db.execute('SELECT * FROM proposals WHERE id=?',(pid,)).fetchone()
        if not p:
            raise HTTPException(404,'Заявка не найдена')
        if data.status=='published' and p['status'] not in ('paid_development','published'):
            raise HTTPException(409,'Для публикации нужен оплаченный заказ на разработку и редакционная проверка')
        db.execute('UPDATE proposals SET status=?,updated_at=? WHERE id=?',(data.status,now(),pid))
        db.execute('INSERT INTO messages(proposal_id,sender_id,kind,text,created_at) VALUES(?,?,?,?,?)',
                   (pid,editor['id'],'editor',data.note.strip() or 'Редактор обновил статус: '+data.status,now()))
    return {'status':data.status}


@app.get('/api/community/{pid}')
def community_story(pid:int,request:Request):
    user=get_user(request)
    with conn() as db:
        p=db.execute('SELECT p.id,p.city,p.title,p.synopsis,p.source_url,p.price_kopeks,p.status,p.user_id,u.username AS author FROM proposals p JOIN users u ON u.id=p.user_id WHERE p.id=?',(pid,)).fetchone()
    if not p or p['status']!='published':
        raise HTTPException(404,'История не опубликована')
    owned=bool(user and (user['id']==p['user_id'] or unlocked(user['id'],product_key(proposal_id=pid))))
    payload={k:p[k] for k in ('id','city','title','price_kopeks','author','source_url')}
    payload['owned']=owned
    if owned:
        payload['synopsis']=p['synopsis']
    else:
        payload['preview']=p['synopsis'][:260]+'…'
    return payload


@app.get('/api/health')
def health():
    return {'ok':True,'cities':len(CASES),'payments_connected':bool(SHOP_ID and SHOP_SECRET)}


@app.get('/cities/{slug}/index.html')
@app.get('/cities/{slug}/')
def case_page(slug:str,request:Request):
    if slug not in BY_SLUG:
        raise HTTPException(404,'Город не найден')
    user=get_user(request)
    if not user or not unlocked(user['id'],product_key(case_slug=slug)):
        return RedirectResponse('/access.html?slug='+quote(slug),status_code=303)
    return FileResponse(BASE/'cities'/slug/'index.html',media_type='text/html',headers={'Cache-Control':'private, no-store'})


@app.get('/access.html')
def access_page():
    return FileResponse(BASE/'access.html')


@app.get('/profile.html')
def profile_page():
    return FileResponse(BASE/'profile.html')


@app.get('/creators.html')
def creators_page():
    return FileResponse(BASE/'creators.html')


@app.get('/marketplace.html')
def marketplace_page():
    return FileResponse(BASE/'marketplace.html')


@app.get('/story.html')
def story_page():
    return FileResponse(BASE/'story.html')


@app.get('/')
@app.get('/index.html')
def home():
    return FileResponse(BASE/'index.html',media_type='text/html')


@app.get('/{filename}')
def frontend_file(filename:str):
    # Whitelist ONLY static public files, never DB, source code or config.
    allowed={'style.css','app.js','data.js','map-pins.js','credits.html','commerce.js','commerce.css','favicon.ico'}
    if filename not in allowed or not (BASE/filename).is_file():
        raise HTTPException(404,'Не найдено')
    return FileResponse(BASE/filename)

class PayoutTokenIn(BaseModel):
    token: str = Field(min_length=20,max_length=600)


@app.post('/api/author/payout-token')
def save_payout_token(data:PayoutTokenIn,request:Request):
    check_origin(request)
    user=get_user(request,True)
    if not (SHOP_ID and SHOP_SECRET and SAFE_DEAL_ENABLED and PAYOUT_CIPHER):
        raise HTTPException(503,'Выплаты через Безопасную сделку пока не активированы')
    # Only the YooMoney payout widget's opaque token is stored. NEVER receive raw card numbers here.
    if re.fullmatch(r'\d{12,19}',data.token.strip()):
        raise HTTPException(422,'Нельзя передавать номер карты, нужен токен из виджета')
    with conn() as db:
        db.execute('INSERT INTO payout_methods(user_id,provider,payout_token,updated_at) VALUES(?,?,?,?) '
                   'ON CONFLICT(user_id) DO UPDATE SET payout_token=excluded.payout_token,updated_at=excluded.updated_at',
                   (user['id'],'yookassa_safe_deal',PAYOUT_CIPHER.encrypt(data.token.strip().encode()).decode(),now()))
    return {'ok':True,'message':'Способ выплат сохранён'}


@app.get('/api/admin/payouts')
def pending_payouts(request:Request):
    require_admin(request)
    with conn() as db:
        rows=[dict(r) for r in db.execute('''SELECT l.order_id,l.seller_id,u.username,l.seller_amount,l.platform_amount,
                         l.payout_status,l.created_at,o.deal_id,pm.user_id AS payout_connected
                         FROM ledger l JOIN orders o ON o.id=l.order_id
                         JOIN users u ON u.id=l.seller_id
                         LEFT JOIN payout_methods pm ON pm.user_id=l.seller_id ORDER BY l.created_at DESC LIMIT 150''')]
    return {'payouts':rows}


@app.post('/api/admin/payouts/{order_id}/send')
def send_payout(order_id:str,request:Request):
    check_origin(request)
    require_admin(request)
    if not (SHOP_ID and SHOP_SECRET and SAFE_DEAL_ENABLED and PAYOUT_CIPHER):
        raise HTTPException(503,'Нужен активный договор Безопасной сделки с ЮKassa')
    with conn() as db:
        row=db.execute('''SELECT l.*,o.deal_id,o.status as order_status,pm.payout_token FROM ledger l
                   JOIN orders o ON o.id=l.order_id
                   LEFT JOIN payout_methods pm ON pm.user_id=l.seller_id WHERE l.order_id=?''',(order_id,)).fetchone()
    if not row:
        raise HTTPException(404,'Выплата не найдена')
    if row['payout_status'] in ('pending_provider','succeeded'):
        return {'status':row['payout_status'],'payout_id':row['payout_id']}
    if not row['deal_id'] or not row['payout_token'] or row['order_status']!='paid':
        raise HTTPException(409,'Сделка не оплачена или автор не подключил карту')
    try:
        decrypted_token=PAYOUT_CIPHER.decrypt(row['payout_token'].encode()).decode()
    except InvalidToken:
        raise HTTPException(409,'Токен выплат повреждён. Попросите автора заново привязать карту')
    data=yoomoney('payouts',{'amount':{'value':money(row['seller_amount']),'currency':'RUB'},
            'payout_token':decrypted_token,
            'description':'ТЁМНОЕ ДЕЛО: вознаграждение автора',
            'metadata':{'order_id':order_id},'deal':{'id':row['deal_id']}},'payout-'+order_id)
    with conn() as db:
        db.execute('UPDATE ledger SET payout_status=?,payout_id=? WHERE order_id=?',
                   ('succeeded' if data.get('status')=='succeeded' else 'pending_provider',data['id'],order_id))
    return {'status':data.get('status'),'payout_id':data.get('id')}


@app.post('/api/admin/payouts/{order_id}/verify')
def verify_payout(order_id:str,request:Request):
    check_origin(request)
    require_admin(request)
    with conn() as db:
        r=db.execute('SELECT payout_id FROM ledger WHERE order_id=?',(order_id,)).fetchone()
    if not r or not r['payout_id']:
        raise HTTPException(404,'Выплата не создана')
    obj=yoomoney('payouts/'+r['payout_id'])
    status=obj.get('status','unknown')
    if status in ('succeeded','canceled'):
        with conn() as db:
            db.execute('UPDATE ledger SET payout_status=? WHERE order_id=?',(status,order_id))
    return {'status':status}
