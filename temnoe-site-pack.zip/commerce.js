(() => {
'use strict';
const $=(s,base=document)=>base.querySelector(s);

function demoNotice(){
  if(document.querySelector('#td-demo-notice'))return;
  const notice=document.createElement('aside');
  notice.id='td-demo-notice';
  notice.className='td-demo-notice';
  notice.textContent='ТЕСТОВАЯ ВЕРСИЯ · Все покупки условные, реальные деньги не списываются. Не используйте рабочие пароли. Данные могут сбрасываться.';
  document.body.prepend(notice);
}

const $$=(s,base=document)=>[...base.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const root=document.body.dataset.root||'';
const screen=document.body.dataset.screen||'';
let me={user:null}, config={};
const cityList=(window.TD_CASES||[]);
const money=k=>`${(k/100).toLocaleString('ru-RU',{minimumFractionDigits:0,maximumFractionDigits:2})} ₽`;
const qs=()=>new URLSearchParams(location.search);
const slugToCase=s=>cityList.find(c=>c.slug===s);
const show=(message)=>{let old=$('.market-alert');if(old)old.remove();let a=document.createElement('div');a.className='market-alert';a.setAttribute('role','alert');a.textContent=message;document.body.appendChild(a);setTimeout(()=>a.remove(),4500)};
async function api(url,body,method='POST'){
  const r=await fetch('/api/'+url,{method:body===undefined?'GET':method,headers:body===undefined?{}:{'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body),credentials:'same-origin'});
  let j;try{j=await r.json()}catch{j={}};
  if(!r.ok)throw new Error(typeof j.detail==='string'?j.detail:'Ошибка сервера: '+r.status);
  return j;
}
async function refresh(){try{[me,config]=await Promise.all([api('me'),api('config')])}catch(e){console.warn(e);}}
function formatDate(ts){return new Date(ts*1000).toLocaleDateString('ru-RU')}
function injectNav(){
  const nav=$('#navlinks')||$('.navlinks');
  if(nav&&!$('#commerce-nav-link')){
    nav.insertAdjacentHTML('beforeend','<a id="commerce-nav-link" href="/marketplace.html">Истории авторов</a><a href="/creators.html">Предложить историю</a>');
  }
  const top=$('.navright');
  if(top&&!$('#commerce-profile-link')){
    top.insertAdjacentHTML('beforeend','<a id="commerce-profile-link" href="/profile.html" class="btn dark" style="min-height:37px;padding:8px 14px;font-size:12px">'+(me.user?'Кабинет':'Войти')+'</a>');
  }
}
function mountModal(){
  if($('#authOverlay'))return;
  document.body.insertAdjacentHTML('beforeend',`<div class="market-modal" id="authOverlay"><div class="market-panel"><button class="market-x" data-close-auth aria-label="Закрыть">×</button><span class="market-overline">АККАУНТ СЛЕДОВАТЕЛЯ</span><h2 id="authHeading">Войти в игру</h2><p class="market-note">Прогресс, бесплатное дело, покупки и истории автора будут привязаны к аккаунту.</p><form class="market-form" id="authForm"><label class="market-field" id="nameWrap" hidden>Как тебя зовут?<input name="username" placeholder="Твоё имя" maxlength="60"></label><label class="market-field">Электронная почта<input name="email" type="email" required autocomplete="email"></label><label class="market-field">Пароль<input name="password" type="password" required minlength="8" autocomplete="current-password"></label><button class="market-button" type="submit" id="authSubmit">Войти</button></form><button type="button" class="market-button secondary" style="width:100%;margin-top:10px" id="authSwitch">Создать аккаунт</button><p class="market-note" id="authError" role="alert"></p></div></div>`);
  let register=false;
  $('#authSwitch').onclick=()=>{register=!register;$('#authHeading').textContent=register?'Регистрация':'Войти в игру';$('#nameWrap').hidden=!register;$('#authSubmit').textContent=register?'Зарегистрироваться':'Войти';$('#authSwitch').textContent=register?'Уже есть аккаунт? Войти':'Создать аккаунт';$('#authError').textContent=''};
  $('[data-close-auth]').onclick=()=>$('#authOverlay').classList.remove('open');
  $('#authOverlay').onclick=e=>{if(e.target.id==='authOverlay')$('#authOverlay').classList.remove('open')};
  $('#authForm').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));$('#authError').textContent='';try{await api('auth/'+(register?'register':'login'),data);await refresh();$('#authOverlay').classList.remove('open');show('Аккаунт готов. Можешь продолжать расследование.');injectNav();window.dispatchEvent(new Event('td:logged-in'));}catch(err){$('#authError').textContent=err.message}};
}
function needAuth(){if(me.user)return true;mountModal();$('#authOverlay').classList.add('open');return false}
async function beginCheckout(args){
  if(!needAuth())return;
  try{
    const order=await api('checkout',args);
    if(order.already_owned){show('Дело уже доступно в твоём архиве');window.location.reload();return}
    if(order.demo){
      const d=$('#paymentOverlay');if(d)d.remove();
      document.body.insertAdjacentHTML('beforeend',`<div class="market-modal open" id="paymentOverlay"><div class="market-panel"><button class="market-x" data-cancel-payment aria-label="Закрыть">×</button><span class="market-overline">ТЕСТОВЫЙ ПЛАТЁЖ · ДЕНЬГИ НЕ СПИСЫВАЮТСЯ</span><h2>Проверка покупки</h2><p>В реальном запуске здесь откроется безопасная платёжная страница. Сейчас можно проверить логику покупки без списания средств.</p><div class="market-facts"><span>Сумма: <b>${money(order.amount_kopeks)}</b></span><span>Тестовая операция</span></div><button class="market-button" id="confirmPayment" style="width:100%">Имитировать успешную оплату</button><p class="market-note">Только для тестовой версии. Реальные деньги не списываются, а тестовые данные могут сброситься.</p></div></div>`);
      $('[data-cancel-payment]').onclick=()=>$('#paymentOverlay').remove();
      $('#confirmPayment').onclick=async()=>{try{await api('dev/complete/'+order.order_id,{});$('#paymentOverlay').remove();show('Тестовая покупка выполнена, деньги не списывались.');await refresh();window.dispatchEvent(new Event('td:paid'));if(screen==='creators'&&args.kind==='creation')loadProposals(args.proposal_id);}catch(e){show(e.message)}};
    }else if(order.confirmation_url){window.location.href=order.confirmation_url}
  }catch(e){show(e.message)}
}
function navbarPage(){return `<header class="nav"><div class="shell navinner"><a href="/" class="brand"><img src="/assets/logo.webp" alt="ТЁМНОЕ ДЕЛО"></a><nav class="navlinks open-for-desktop"><a href="/">Главная</a><a href="/#catalog">Города</a><a href="/marketplace.html">Истории авторов</a><a href="/creators.html">Стать автором</a></nav><div class="navright"><a href="/profile.html" class="btn dark" style="min-height:37px;padding:8px 14px;font-size:12px">Личный кабинет</a></div></div></header>`}
function footer(){return `<footer class="market-footer"><div class="market-shell">ТЁМНОЕ ДЕЛО · Реальные истории и городские легенды. Факты отделяем от художественной реконструкции. <a href="/" style="color:#ffb166">Главная</a> · <a href="/creators.html" style="color:#ffb166">Стать автором</a></div></footer>`}
function shell(title,eyebrow,lead,body){document.body.innerHTML=navbarPage()+`<main class="market-body"><section class="market-hero"><div class="market-shell"><div class="market-overline">${eyebrow}</div><h1>${title}</h1><p class="market-lead">${lead}</p></div></section><div class="market-shell market-main" id="marketContent">${body}</div></main>`+footer();mountModal()}
function renderAccess(){
  const slug=qs().get('slug');const c=slugToCase(slug);
  if(!c){shell('Дело не найдено','АРХИВ ДЕЛ','Уточни город, который хочешь исследовать.','<a class="market-button" href="/">Вернуться в каталог</a>');return}
  const owned=me.entitlements?.includes('case:'+slug);
  const canFree=!!me.user&&me.first_free_available;
  shell(c.city,'ДЕЛО №'+esc(c.number)+' · '+esc(c.district),`<span class="market-highlight">${esc(c.title)}</span>. ${esc(c.summary)}`,
    `<div class="market-grid"><section class="market-panel"><div class="market-photo" style="background-image:url('/assets/illustration-${String(c.id).padStart(2,'0')}.webp')"><div class="market-photo-overlay">${esc(c.city)} · ${esc(c.title)}</div></div><div class="market-divider"></div><h2>Войди в расследование</h2><p>${esc(c.intro)}</p><div class="market-facts"><span>${esc(c.kind)}</span><span>${esc(c.playLength)}</span><span>Настоящие места</span></div><div class="market-actions"><button class="market-button" id="unlockButton">${owned?'Продолжить игру':canFree?'Выбрать бесплатно':me.user?'Открыть за 110 ₽':'Войти и выбрать бесплатно'}</button><a class="market-button secondary" href="/">Все города</a></div><div class="market-note">Бесплатным можно сделать один город на аккаунт. Остальные официальные дела стоят 110 ₽ за доступ к каждой истории. Сейчас это игровые главы, а не двухчасовые расследования.</div></section><aside class="market-panel"><div class="market-overline">ТОЛЬКО ПЕРВОЕ ДЕЛО</div><h2>Первый город — бесплатно</h2><div class="market-facts"><span>1 бесплатно</span><span>Далее 110 ₽</span><span>Доступ сохраняется</span></div><p>Выбираешь любое из сорока городских дел, проходишь его и сохраняешь прогресс. Потом открываешь новые истории по одной.</p><div class="market-divider"></div><h3>Реальная основа</h3><p>${esc(c.fact)}</p><a class="market-button secondary" target="_blank" rel="noopener" href="${esc(c.source)}">Открыть исторический источник ↗</a></aside></div>`);
  $('#unlockButton').onclick=async()=>{
    if(owned){location.href='/cities/'+slug+'/index.html';return}
    if(!needAuth())return;
    if(me.first_free_available){try{const result=await api('claim-free',{slug});location.href=result.url}catch(e){show(e.message)}}
    else await beginCheckout({kind:'city',slug});
  };
}
function renderProfile(){
  if(!me.user){shell('Твой архив','АККАУНТ СЛЕДОВАТЕЛЯ','Войди или создай аккаунт, чтобы сохранять истории и прогресс.',`<section class="market-panel"><h2>Ты ещё не вошёл</h2><p>Один любой город бесплатно, потом по 110 ₽ за каждое следующее расследование.</p><button id="loginNow" class="market-button">Войти / зарегистрироваться</button></section>`);$('#loginNow').onclick=()=>needAuth();return}
  const owned=(me.entitlements||[]).filter(p=>p.startsWith('case:')).map(p=>cityList.find(x=>x.slug===p.split(':')[1])).filter(Boolean);
  shell('Личный кабинет','ТВОЙ ПРОГРЕСС',`Привет, ${esc(me.user.username)}. Здесь все твои истории и выплаты.`,
    `<div class="market-grid two-one"><section class="market-panel"><h2>Мои расследования</h2><p>${me.first_free_available?'Твой первый город ещё не выбран. Он будет бесплатным.':'Бесплатный город уже выбран. Новые истории открываются за 110 ₽.'}</p><div class="market-list">${owned.length?owned.map(c=>`<div class="market-listitem"><div class="top"><strong>${esc(c.city)} · ${esc(c.title)}</strong><a class="market-button secondary" href="/cities/${esc(c.slug)}/index.html">Продолжить →</a></div></div>`).join(''):'<div class="market-empty">Пока пусто. Выбери первое дело.</div>'}</div><div class="market-actions"><a class="market-button" href="/#catalog">Выбрать город</a><a class="market-button secondary" href="/creators.html">Мои истории</a></div><div class="market-divider"></div><h3>Мои заказы</h3><div class="market-list">${(me.orders||[]).length?me.orders.map(o=>`<div class="market-listitem"><div class="top"><strong>${esc(o.product)}</strong><span class="market-pill">${money(o.amount_kopeks)}</span></div><p>${esc(o.status)} · ${formatDate(o.created_at)}</p></div>`).join(''):'Заказов пока нет.'}</div></section><aside class="market-panel"><span class="market-overline">ПЛОЩАДКА АВТОРОВ</span><h2>Мои доходы</h2><div class="market-people"><b>${money(me.earnings_kopeks||0)}</b> начислено за продажи</div><p>От продаж авторских историй тебе начисляется 90%, площадке 10%. Вывод на карту подключается через ЮKassa после активации договора и подтверждения платёжных данных.</p><div id="payoutForm"></div><div class="market-actions"><button class="market-button secondary" id="logoutNow">Выйти из аккаунта</button></div></aside></div>`);
  $('#logoutNow').onclick=async()=>{await api('auth/logout',{});location.href='/'};
  if(config.marketplace_live){
    $('#payoutForm').innerHTML=`<div class="market-divider"></div><h3>Привязать карту для выплат</h3><div id="yooPayoutWidget"></div><p class="market-note">Данные карты вводятся только в защищённом виджете ЮKassa, наш сайт их не получает.</p>`;
    const s=document.createElement('script');s.src='https://static.yoomoney.ru/payouts-data-widget-front/widget.js';s.onload=()=>{try{const widget=new window.PayoutsData({successCallback:async data=>{try{await api('author/payout-token',{token:data.payout_token});show('Способ получения выплат подключён')}catch(e){show(e.message)}},errorCallback:()=>show('Ошибка при привязке карты')});widget.render('yooPayoutWidget')}catch(e){show('Платёжный виджет не запустился')}};document.body.appendChild(s);
  }
}
function renderCreators(){
  shell('Истории создают люди','ТВОЯ ИСТОРИЯ · ТВОЙ ГОРОД','Не нашёл город? Или знаешь местную байку, которую никто не рассказывает? Пришли нам историю в редакционный чат. Ты выбираешь цену для будущих покупателей.',
    `<div class="market-grid"><section class="market-panel"><h2>Предложить историю</h2><div class="market-callout">Прислать идею и источники можно бесплатно. Если закажешь разработку полноценного интерактивного дела нашей командой, стоимость 1 000 ₽. После проверки и публикации 90% с продаж получит автор, 10% — площадка.</div><form class="market-form" id="proposalForm" style="margin-top:18px"><label class="market-field">Город<input name="city" required minlength="2" maxlength="80" placeholder="Например, Тверь"></label><label class="market-field">Название истории<input name="title" required minlength="5" maxlength="160" placeholder="Как местные её называют?"></label><label class="market-field">Что случилось?<textarea name="synopsis" required minlength="30" maxlength="6000" rows="6" placeholder="Расскажи историю, что известно, какие есть противоречия и места. Лучше подробно."></textarea></label><label class="market-field">Ссылка на источник (желательно)<input name="source_url" type="url" placeholder="https://..."></label><label class="market-field">Моя цена истории, ₽<input name="price_rub" type="number" min="50" max="10000" value="110"></label><div class="market-facts"><span>Автор получит <b id="authorAmount">99 ₽</b></span><span>Сайт получит <b id="platformAmount">11 ₽</b></span></div><button class="market-button" type="submit">Отправить в чат редакции</button></form><p class="market-note">Мы проверяем источники и права на изображения. Публикация не происходит автоматически.</p></section><aside class="market-panel"><h2>Мои переписки</h2><div id="proposalList" class="market-list"></div><div class="market-divider"></div><div id="proposalThread"><p>Выбери историю из списка, чтобы открыть чат с редакцией.</p></div></aside></div><div class="market-panel" id="editorPanel" style="display:none;margin-top:20px"><h2>Редакторская модерация</h2><div id="adminList" class="market-list"></div></div>`);
  $('#proposalForm').price_rub.oninput=()=>{let v=Number($('#proposalForm').price_rub.value||0);$('#authorAmount').textContent=money(v*90);$('#platformAmount').textContent=money(v*10)};
  $('#proposalForm').onsubmit=async e=>{e.preventDefault();if(!needAuth())return;let data=Object.fromEntries(new FormData(e.target));data.price_rub=+data.price_rub;try{let p=await api('proposals',data);show('История отправлена! Теперь можно общаться в чате.');await refresh();loadProposals(p.id)}catch(e){show(e.message)}};
  loadProposals();
  if(me.user?.role==='admin') loadAdmin();
}
async function loadProposals(openId){
  const list=$('#proposalList');if(!list)return;
  if(!me.user){list.innerHTML='<div class="market-empty">Войди, чтобы видеть свои истории и чат.</div>';return}
  await refresh();const ps=me.my_proposals||[];
  list.innerHTML=ps.length?ps.map(p=>`<button class="market-listitem" data-proposal="${p.id}" style="text-align:left;color:inherit;cursor:pointer;width:100%"><div class="top"><strong>${esc(p.city)} · ${esc(p.title)}</strong><span class="market-pill">${esc(p.status)}</span></div><p>Цена ${money(p.price_kopeks)}</p></button>`).join(''):'<div class="market-empty">Ты ещё не предложил ни одной истории.</div>';
  $$('[data-proposal]',list).forEach(b=>b.onclick=()=>openThread(+b.dataset.proposal));
  if(openId)openThread(openId);
}
async function openThread(pid){
  let data;try{data=await api('proposals/'+pid)}catch(e){show(e.message);return}
  const p=data.proposal;const el=$('#proposalThread');if(!el)return;
  el.innerHTML=`<span class="market-overline">РЕДАКЦИОННЫЙ ЧАТ · №${pid}</span><h3>${esc(p.city)} · ${esc(p.title)}</h3><p class="market-note">Статус: ${esc(p.status)}</p><div class="market-thread" id="threadMessages">${data.messages.map(m=>`<div class="market-bubble ${esc(m.kind)}"><small>${esc(m.username|| (m.kind==='system'?'Система':'Редакция'))} · ${formatDate(m.created_at)}</small>${esc(m.text)}</div>`).join('')}</div><form id="messageForm" class="market-form"><label class="market-field">Новое сообщение<textarea name="text" rows="3" required maxlength="4000" placeholder="Дополнительные подробности, ссылки, свидетели..."></textarea></label><button class="market-button">Отправить сообщение</button></form><div class="market-divider"></div><div class="market-facts"><span>Разработка: 1 000 ₽</span><span>Автор получает 90%</span></div><div class="market-actions"><button id="devOrder" class="market-button secondary">Заказать разработку за 1 000 ₽</button></div><form class="market-form" style="margin-top:14px" id="changePriceForm"><label class="market-field">Цена истории для игроков, ₽<input name="price_rub" type="number" value="${p.price_kopeks/100}" min="50" max="10000"></label><button class="market-button secondary">Сохранить цену</button></form>`;
  const thread=$('#threadMessages');thread.scrollTop=thread.scrollHeight;
  $('#messageForm').onsubmit=async e=>{e.preventDefault();let text=e.target.text.value;try{await api('proposals/'+pid+'/messages',{text});openThread(pid)}catch(e){show(e.message)}};
  $('#changePriceForm').onsubmit=async e=>{e.preventDefault();try{await api('proposals/'+pid+'/price',{price_rub:+e.target.price_rub.value});show('Цена обновлена');loadProposals(pid)}catch(e){show(e.message)}};
  $('#devOrder').onclick=()=>beginCheckout({kind:'creation',proposal_id:pid});
  if(!['proposed','reviewed'].includes(p.status))$('#devOrder').disabled=true;
}
async function loadAdmin(){
  let items;try{items=(await api('admin/proposals')).proposals}catch(e){return}
  $('#editorPanel').style.display='block';
  $('#adminList').innerHTML=items.length?items.map(p=>`<div class="market-listitem"><strong>${esc(p.city)} · ${esc(p.title)}</strong> <span class="market-pill">${esc(p.status)}</span><p>${esc(p.username)} · ${esc(p.email)} · ${esc(p.source_url)}</p><div class="market-actions"><button class="market-button secondary" data-review="${p.id}">На проверке</button><button class="market-button" data-publish="${p.id}">Опубликовать</button><button class="market-button danger" data-reject="${p.id}">Отклонить</button></div></div>`).join(''):'Нет заявок';
  $$('[data-review],[data-publish],[data-reject]',$('#editorPanel')).forEach(b=>{b.onclick=async()=>{const pid=Number(b.dataset.review||b.dataset.publish||b.dataset.reject);let status=b.dataset.review?'reviewed':b.dataset.publish?'published':'rejected';try{await api('admin/proposals/'+pid+'/moderate',{status,note:'Редакционный статус: '+status});show('Статус обновлён');loadAdmin()}catch(e){show(e.message)}}});
}
async function renderMarketplace(){
  const data=await api('cases');
  shell('Истории наших авторов','СООБЩЕСТВО СЛЕДОВАТЕЛЕЙ','Местные истории, присланные самими жителями. Цену устанавливает автор. При продаже он получает 90%, платформа — 10%.',
    `<div class="market-facts"><span>Историю может предложить каждый</span><span>Автору 90%</span><span>Площадке 10%</span></div><div class="market-tiles" id="communityTiles">${data.community.length?data.community.map(s=>`<article class="market-tile"><div class="market-overline">${esc(s.city)}</div><h3>${esc(s.title)}</h3><p>Автор: ${esc(s.author)}</p><footer><span class="market-pill">${money(s.price_kopeks)}</span><a href="/story.html?id=${s.id}" class="market-button secondary">Подробнее</a></footer></article>`).join(''):'<div class="market-empty">Первые авторские истории ещё проходят модерацию. Можешь предложить свою.</div>'}</div><div class="market-actions"><a class="market-button" href="/creators.html">Предложить свою историю</a><a class="market-button secondary" href="/#catalog">Официальные 40 дел</a></div>`);
}
async function renderStory(){
  const pid=Number(qs().get('id'));let item;try{item=await api('community/'+pid)}catch(e){shell('История не найдена','АРХИВ АВТОРСКИХ ДЕЛ',e.message,'<a class="market-button" href="/marketplace.html">Вернуться</a>');return}
  shell(esc(item.city),'ИСТОРИЯ АВТОРА · '+esc(item.author),esc(item.title),
     `<div class="market-grid"><article class="market-panel"><h2>${esc(item.title)}</h2><p>${esc(item.owned?item.synopsis:item.preview)}</p>${item.source_url?`<p><a class="market-button secondary market-source" href="${esc(item.source_url)}" rel="noopener" target="_blank">Первоисточник ↗</a></p>`:''}<div class="market-actions"><button class="market-button" id="buyStory">${item.owned?'Доступ открыт':`Открыть за ${money(item.price_kopeks)}`}</button><a class="market-button secondary" href="/marketplace.html">Все авторские истории</a></div></article><aside class="market-panel"><span class="market-overline">ДОЛЯ АВТОРА</span><h2>90% за каждую покупку</h2><div class="market-facts"><span>${money(Math.round(item.price_kopeks*.9))} автору</span><span>${money(item.price_kopeks-Math.round(item.price_kopeks*.9))} площадке</span></div><p>Автор сам устанавливает цену и передаёт материалы в редакцию. История публикуется после проверки. К ней можно привязать полноценную интерактивную игру.</p></aside></div>`);
  $('#buyStory').onclick=()=>item.owned?show('История уже в твоём архиве'):beginCheckout({kind:'story',proposal_id:pid});
  window.addEventListener('td:paid',()=>location.reload(),{once:true});
}
async function init(){await refresh(); if(config.payment_mode==='demo')demoNotice();
  if(screen==='access')renderAccess();
  else if(screen==='profile')renderProfile();
  else if(screen==='creators')renderCreators();
  else if(screen==='marketplace')await renderMarketplace();
  else if(screen==='story')await renderStory();
  else{
    injectNav();
    const d=$('#showStoryForm');if(d){d.outerHTML='<a class="btn" href="/creators.html">ПРЕДЛОЖИТЬ ИСТОРИЮ ↗</a>'}
    const hero=$('.benefits');if(hero){hero.insertAdjacentHTML('beforebegin','<div class="market-pricestrip"><span>🎁 <b>Первый город бесплатно</b></span><span>🗂 Другие истории по <b>110 ₽</b></span><span>✍️ Предложи свою историю и получай <b>90% с продаж</b></span><a href="/creators.html" style="color:#ffb35b;text-decoration:underline">Стать автором ↗</a></div>')}
    const disclaimer=$('.community p');if(disclaimer)disclaimer.textContent='Отправь местную историю в чат редакции, а после проверки сможешь заказать её разработку и получать 90% с продаж.';
  }
  mountModal();
  window.addEventListener('td:logged-in',()=>{if(screen==='creators'){loadProposals()}else if(screen)location.reload()});
  window.addEventListener('td:paid',()=>{if(screen==='creators')loadProposals();else if(screen==='access')location.reload();else if(screen==='profile')renderProfile()});
  if(qs().get('payment')){try{let id=qs().get('payment');const v=await api('orders/'+id+'/verify',{});show(v.status==='paid'?'Оплата подтверждена, доступ открыт':'Платёж проверяется: '+v.status);await refresh()}catch(e){show(e.message)}}
}
document.addEventListener('DOMContentLoaded',init);
})();
