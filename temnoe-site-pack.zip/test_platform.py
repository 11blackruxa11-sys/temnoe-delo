"""Smoke and accounting tests using an isolated temporary SQLite file."""
from pathlib import Path
import importlib.util
import os
import tempfile
import sys
from fastapi.testclient import TestClient


def app_client(tmp):
    os.environ['TD_DB_PATH'] = str(tmp / 'test.sqlite3')
    os.environ['TD_DEMO_PAYMENTS'] = '1'
    os.environ['APP_ENV'] = 'development'
    os.environ['ADMIN_EMAIL'] = 'editor@example.org'
    spec=importlib.util.spec_from_file_location('darkcase_test_server', Path(__file__).parent/'server.py')
    m=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=m
    spec.loader.exec_module(m)
    return TestClient(m.app),m


def account(c,email):
    r=c.post('/api/auth/register',json={'email':email,'password':'correct-horse-battery','username':'Тест'})
    assert r.status_code==200,r.text
    return r.json()['user']


def test_main():
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp=Path(tmpdir)
        c,m=app_client(tmp)
        assert c.get('/').status_code==200
        assert c.get('/api/health').json()['cities']==40
        assert c.get('/server.py').status_code==404
        assert c.get('/cities/case-01/index.html',follow_redirects=False).status_code==303
        account(c,'buyer@example.org')
        assert c.get('/api/me').json()['first_free_available'] is True
        # First chosen city free and persists, one and only one.
        free=c.post('/api/claim-free',json={'slug':'case-05'})
        assert free.status_code==200,free.text
        assert c.get('/cities/case-05/index.html').status_code==200
        assert c.post('/api/claim-free',json={'slug':'case-05'}).json()['already_owned']==True
        assert c.post('/api/claim-free',json={'slug':'case-06'}).status_code==409
        # Additional official city purchased for 110 RUB in explicit sandbox mode.
        order=c.post('/api/checkout',json={'kind':'city','slug':'case-06'})
        assert order.status_code==200,order.text
        assert order.json()['amount_kopeks']==11000
        oid=order.json()['order_id']
        assert c.get('/cities/case-06/index.html',follow_redirects=False).status_code==303
        assert c.post('/api/dev/complete/'+oid).status_code==200
        assert c.post('/api/dev/complete/'+oid).json()['already_processed']==True
        assert c.get('/cities/case-06/index.html').status_code==200
        # Submit story and chat in persistent SQLite.
        prop=c.post('/api/proposals',json={'city':'Выборг','title':'Тайна старой башни','synopsis':'Об этом месте в городе ходили разные истории. Мы нашли архивную публикацию.', 'source_url':'https://example.org/source','price_rub':100})
        assert prop.status_code==200,prop.text
        pid=prop.json()['id']
        assert c.post(f'/api/proposals/{pid}/messages',json={'text':'Нашёл ещё одну статью'}).status_code==200
        assert len(c.get(f'/api/proposals/{pid}').json()['messages'])>=3
        price=c.post(f'/api/proposals/{pid}/price',json={'price_rub':100}).json()
        assert price['author_share_kopeks']==9000 and price['platform_share_kopeks']==1000
        # Pay for creation: 1000 RUB and moderator approval required.
        creation=c.post('/api/checkout',json={'kind':'creation','proposal_id':pid})
        assert creation.status_code==200,creation.text
        assert creation.json()['amount_kopeks']==100000
        c.post('/api/dev/complete/'+creation.json()['order_id'])
        assert c.get(f'/api/proposals/{pid}').json()['proposal']['status']=='paid_development'
        assert c.post(f'/api/admin/proposals/{pid}/moderate',json={'status':'published'}).status_code==403
        # Editor approves, then buyer purchases author's story, 90/10 split.
        editor=TestClient(m.app)
        account(editor,'editor@example.org')
        pub=editor.post(f'/api/admin/proposals/{pid}/moderate',json={'status':'published','note':'Источники проверены редактором'})
        assert pub.status_code==200,pub.text
        buyer2=TestClient(m.app)
        account(buyer2,'reader2@example.org')
        pay=buyer2.post('/api/checkout',json={'kind':'story','proposal_id':pid})
        assert pay.status_code==200,pay.text
        assert pay.json()['amount_kopeks']==10000
        buyer2.post('/api/dev/complete/'+pay.json()['order_id'])
        assert buyer2.get(f'/api/community/{pid}').json()['owned']==True
        earned=c.get('/api/author/earnings').json()
        assert earned['gross_kopeks']==9000,earned
        assert len(earned['transactions'])==1
        assert earned['transactions'][0]['platform_amount']==1000
        # Unauthorized access to another author's private conversation blocked.
        assert buyer2.get(f'/api/proposals/{pid}').status_code==403
        # No payout can be attempted without a signed provider agreement.
        assert editor.post('/api/admin/payouts/'+pay.json()['order_id']+'/send').status_code==503
        print('PASS: auth, free selection, price 110, persistent chat, paid creation, moderation, 90/10 split, gates, payout protection')

if __name__=='__main__':test_main()
